# SM Consultancy Services — Payroll Portal

A self-contained, single-file HTML payroll management portal for SM Consultancy Services.

**Developed by:** SM Consultancy Services

## What's inside
- `index.html` — the entire app (HTML + CSS + JavaScript). Both brand images (the circular "SM" logo and the office background photo) are embedded directly in the file as base64, so it works fully offline with no broken image links.

## How to run it
1. Double-click `index.html` to open it in any modern browser (Chrome/Edge recommended).
2. Log in with the demo account:
   - **Username:** `admin`
   - **Password:** `admin123`
3. Data (employees, salaries, attendance, payslip history) is saved in your browser's local storage, so it persists between visits on the same device/browser.

## Features
- Employee management (Full-Time & Part-Time)
- Salary, bonus & overtime handling
- Attendance tracking
- Payslip generation, printing & download
- Salary trend graphs and full-time/part-time pie chart

## Want a real, shareable public link?
This zip is a static, offline site — there's no server involved, so it doesn't have a live URL out of the box. To get one, upload the contents of this folder to a free static host, for example:

- **GitHub Pages:** create a repo, upload `index.html`, enable Pages in repo Settings → your site is live at `https://<username>.github.io/<repo>/`
- **Netlify Drop:** go to app.netlify.com/drop and drag this folder in — you get an instant public link
- **Vercel:** `vercel deploy` from this folder (with the Vercel CLI) also gives you a public link

Any of these takes under 2 minutes since it's just one HTML file.
